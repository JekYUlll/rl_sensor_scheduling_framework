#!/usr/bin/env python3
"""Generate the SCENEBAL-1 24-seed evidence figure."""
from __future__ import annotations

import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
OUT_DIR = Path(__file__).resolve().parent
OLDCLAIM = ROOT / "reports/aggregate/scenebal1_24seed_93_116_router_conf05_oldclaim_20260621/oldclaim_seed_summary.csv"
MACRO = ROOT / "reports/aggregate/scenebal1_24seed_93_116_router_conf05_macro_20260621/metpair_seed_summary.csv"


plt.rcParams.update(
    {
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif"],
        "font.size": 8.5,
        "axes.titlesize": 9.5,
        "axes.titleweight": "bold",
        "axes.labelsize": 8.5,
        "legend.fontsize": 7.5,
        "legend.frameon": False,
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.18,
        "grid.linestyle": "-",
    }
)

COLORS = {
    "pdppo": "#E76F51",
    "pass": "#2A9D8F",
    "miss": "#B0BEC5",
    "threshold": "#264653",
    "macro": "#0072B2",
    "text": "#333333",
}


def as_float(value: str) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def as_bool(value: str) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def load_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def main() -> None:
    old_rows = load_rows(OLDCLAIM)
    macro_rows = {int(r["seed"]): r for r in load_rows(MACRO)}

    records = []
    for row in old_rows:
        seed = int(row["seed"])
        step_margin = as_float(row["step_margin_vs_replay_static_reference"])
        reference_loss = as_float(row["replay_static_reference_loss"])
        strict_threshold = max(0.001, 0.002 * reference_loss)
        records.append(
            {
                "seed": seed,
                "step_margin": step_margin,
                "strict_threshold": strict_threshold,
                "strict_pass": as_bool(row["learned_true_static_step_gate_pass"]),
                "true_macro_margin": as_float(macro_rows[seed]["learned_macro_margin_abs_vs_macro_static_reference"]),
            }
        )

    records = sorted(records, key=lambda item: item["step_margin"])
    seeds = [r["seed"] for r in records]
    x = np.arange(len(records))
    step_margins = np.array([r["step_margin"] for r in records])
    thresholds = np.array([r["strict_threshold"] for r in records])
    bar_colors = [COLORS["pass"] if r["strict_pass"] else COLORS["miss"] for r in records]

    gate_names = [
        "Operational\nstep",
        "Operational\nmacro",
        "Explicit\nreplay step",
        "Explicit\nreplay macro",
        "Behaviour\ncomplexity",
        "True-static\nmacro",
        "True-static\nstep > 0",
        "True-static\nstep strict",
    ]
    gate_passes = np.array([24, 24, 24, 24, 24, 24, 24, 24])
    gate_total = 24

    fig, (ax1, ax2) = plt.subplots(
        1,
        2,
        figsize=(6.85, 2.7),
        gridspec_kw={"width_ratios": [1.55, 1.0], "wspace": 0.28},
    )

    ax1.bar(x, step_margins, color=bar_colors, edgecolor="white", linewidth=0.4, width=0.78)
    ax1.plot(x, thresholds, marker="D", linestyle="None", color=COLORS["threshold"], markersize=3.2, label="Strict threshold")
    ax1.axhline(0.0, color="#555555", linewidth=0.7)
    ax1.set_xticks(x)
    ax1.set_xticklabels(seeds, rotation=45, ha="right")
    ax1.set_ylabel("True-static step margin")
    ax1.set_xlabel("Seed, sorted by margin")
    ax1.set_title("A. Ordinary true-static step margin")
    ax1.legend(loc="upper left")
    ax1.annotate(
        "seed95: minimum\npassing margin",
        xy=(0, step_margins[0]),
        xytext=(1.2, max(step_margins) * 0.38),
        arrowprops={"arrowstyle": "->", "color": COLORS["threshold"], "linewidth": 0.8},
        fontsize=7.2,
        color=COLORS["text"],
    )

    y = np.arange(len(gate_names))
    pass_colors = [COLORS["pass"]] * len(gate_names)
    pass_colors[-1] = COLORS["pdppo"]
    ax2.barh(y, gate_passes, color=pass_colors, edgecolor="white", linewidth=0.4, height=0.62)
    ax2.barh(y, gate_total - gate_passes, left=gate_passes, color="#E6E8EB", edgecolor="white", linewidth=0.4, height=0.62)
    ax2.set_xlim(0, gate_total)
    ax2.set_yticks(y)
    ax2.set_yticklabels(gate_names)
    ax2.invert_yaxis()
    ax2.set_xlabel("Seeds passing gate")
    ax2.set_title("B. Evidence gates")
    ax2.set_xticks([0, 8, 16, 24])
    for yi, value in enumerate(gate_passes):
        ax2.text(
            min(value + 0.25, gate_total - 0.15),
            yi,
            f"{value}/24",
            va="center",
            ha="left" if value < gate_total else "right",
            fontsize=7.3,
            color=COLORS["text"],
        )

    fig.suptitle("SCENEBAL-1 24-seed PD-PPO evidence", fontsize=10.5, fontweight="bold", y=1.03)
    for ext in ("pdf", "png"):
        fig.savefig(OUT_DIR / f"figure_scenebal1_24seed_evidence.{ext}")


if __name__ == "__main__":
    main()
