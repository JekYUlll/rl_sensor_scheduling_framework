#!/usr/bin/env python3
"""Generate PPO training diagnostics from saved 24-seed histories."""
from __future__ import annotations

import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from paper_plot_style import PALETTE, apply_paper_style, save_pdf_png


apply_paper_style(base_size=8.4)

PAPER_DIR = Path(__file__).resolve().parents[1]
ROOT_DIR = PAPER_DIR.parent
OUT_DIR = ROOT_DIR / "reports" / "aggregate" / "training_diagnostics_20260624"
FIG_DIR = PAPER_DIR / "figures"

SEEDS = tuple(range(117, 141))
VARIANTS = {
    "Full PD-PPO": "reports/v31_metpair_backbone_context_ortholinear_balancedobjective_scenebal2_seed{seed}_h075ctxolscbal2_20260621/custom_ppo_training_history.json",
    "No imitation guide": "reports/v31_mechablate_no_imitation_guide_finalbenchmark_seed{seed}_h075fb_noimit_20260623b/custom_ppo_training_history.json",
}


def finite(value: object) -> float:
    try:
        out = float(value)
    except Exception:
        return float("nan")
    return out if math.isfinite(out) else float("nan")


def load_rows() -> pd.DataFrame:
    rows: list[dict[str, float | int | str]] = []
    for variant, pattern in VARIANTS.items():
        for seed in SEEDS:
            path = ROOT_DIR / pattern.format(seed=seed)
            if not path.exists():
                continue
            history = json.loads(path.read_text(encoding="utf-8"))
            for item in history:
                timesteps = int(finite(item.get("timesteps", -1)))
                if timesteps <= 0:
                    continue
                rows.append(
                    {
                        "variant": variant,
                        "seed": seed,
                        "timesteps": timesteps,
                        "loss": finite(item.get("loss")),
                        "entropy": finite(item.get("entropy")),
                        "event_aux_accuracy": finite(item.get("subtype_aux_accuracy")),
                        "event_aux_loss": finite(item.get("subtype_aux_loss")),
                        "awbc_loss": finite(item.get("awbc_loss")),
                        "awbc_label_rate": finite(item.get("awbc_label_rate")),
                    }
                )
    if not rows:
        raise FileNotFoundError("No PPO training histories found for the configured variants.")
    return pd.DataFrame(rows)


def summarise(rows: pd.DataFrame) -> pd.DataFrame:
    value_cols = ["loss", "entropy", "event_aux_accuracy", "event_aux_loss", "awbc_loss", "awbc_label_rate"]
    grouped = rows.groupby(["variant", "timesteps"], as_index=False)
    parts = []
    for col in value_cols:
        item = grouped[col].agg(["mean", "std", "count"]).reset_index()
        item["metric"] = col
        item = item.rename(columns={"mean": "value_mean", "std": "value_std", "count": "seed_count"})
        parts.append(item)
    return pd.concat(parts, ignore_index=True)


def series(summary: pd.DataFrame, variant: str, metric: str) -> pd.DataFrame:
    out = summary[(summary["variant"] == variant) & (summary["metric"] == metric)].copy()
    return out.sort_values("timesteps")


def plot(summary: pd.DataFrame) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.45), constrained_layout=True)
    specs = [
        ("loss", "Training loss", "Loss"),
        ("entropy", "Policy entropy", "Entropy"),
        ("event_aux_accuracy", "Event-context head", "Accuracy"),
    ]
    colors = {"Full PD-PPO": PALETTE["teal"], "No imitation guide": PALETTE["orange"]}
    for ax, (metric, title, ylabel) in zip(axes, specs, strict=True):
        for variant in VARIANTS:
            data = series(summary, variant, metric)
            if data.empty:
                continue
            x = data["timesteps"].to_numpy(dtype=float) / 1000.0
            mean = data["value_mean"].to_numpy(dtype=float)
            std = data["value_std"].fillna(0.0).to_numpy(dtype=float)
            color = colors[variant]
            ax.plot(x, mean, color=color, linewidth=1.25, label=variant)
            ax.fill_between(x, mean - std, mean + std, color=color, alpha=0.14, linewidth=0)
        ax.set_title(title, loc="left")
        ax.set_xlabel("PPO timesteps (k)")
        ax.set_ylabel(ylabel)
        if metric == "event_aux_accuracy":
            ax.set_ylim(0.72, 1.01)
        if metric == "loss":
            ax.set_ylim(bottom=0)
    axes[0].legend(loc="upper right")
    save_pdf_png(fig, FIG_DIR / "figure_training_diagnostics")
    plt.close(fig)


def write_report(rows: pd.DataFrame, summary: pd.DataFrame) -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    final_rows = []
    for variant in VARIANTS:
        variant_rows = rows[rows["variant"] == variant]
        seeds = int(variant_rows["seed"].nunique())
        max_t = int(variant_rows["timesteps"].max())
        last = variant_rows[variant_rows["timesteps"] == max_t]
        final_rows.append(
            {
                "variant": variant,
                "seeds": seeds,
                "max_timesteps": max_t,
                "final_loss_mean": float(last["loss"].mean()),
                "final_entropy_mean": float(last["entropy"].mean()),
                "final_event_aux_accuracy_mean": float(last["event_aux_accuracy"].mean()),
                "final_awbc_label_rate_mean": float(last["awbc_label_rate"].mean()),
            }
        )
    final_df = pd.DataFrame(final_rows)
    rows.to_csv(OUT_DIR / "training_history_rows.csv", index=False)
    summary.to_csv(OUT_DIR / "training_history_summary.csv", index=False)
    final_df.to_csv(OUT_DIR / "training_history_final_summary.csv", index=False)
    lines = [
        "# PPO Training Diagnostics",
        "",
        "This diagnostic uses saved PPO training histories for the 24 final benchmark",
        "seeds and the 24 no-imitation ablation seeds. It reports optimization",
        "traces only. The histories do not contain held-out validation macro score",
        "or validation step loss over training, so this figure is not used as",
        "confirmatory validation-convergence evidence.",
        "",
        "## Final-step summary",
        "",
        final_df.to_markdown(index=False, floatfmt=".4f"),
        "",
        "Artifacts:",
        "- `reports/aggregate/training_diagnostics_20260624/training_history_rows.csv`",
        "- `reports/aggregate/training_diagnostics_20260624/training_history_summary.csv`",
        "- `paper/figures/figure_training_diagnostics.pdf`",
        "",
    ]
    (OUT_DIR / "report.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    rows = load_rows()
    summary = summarise(rows)
    plot(summary)
    write_report(rows, summary)
    print(f"Wrote PPO training diagnostics to {OUT_DIR}")


if __name__ == "__main__":
    main()
