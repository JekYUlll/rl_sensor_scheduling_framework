#!/usr/bin/env python3
"""Generate the continuous-margin mechanism ablation figure."""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from paper_plot_style import PALETTE, apply_paper_style, save_pdf_png


def short_label(label: str) -> str:
    replacements = {
        "Full PD-PPO": "Full",
        "No imitation guide": "No imitation",
        "No event context auxiliary": "No event context\nauxiliary",
        "No event-context auxiliary signal": "No event context\nauxiliary",
        "No balanced training loss": "No balanced\ntraining loss",
    }
    return replacements.get(label, label)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--summary-csv", required=True)
    parser.add_argument("--seed-csv", required=True)
    parser.add_argument("--out", default="paper/figures/figure_mechanism_robustness")
    args = parser.parse_args()

    summary = pd.read_csv(args.summary_csv)
    seeds = pd.read_csv(args.seed_csv)
    variant_order = list(summary["variant"])
    labels = [short_label(str(row["variant_label"])) for _, row in summary.iterrows()]

    apply_paper_style(base_size=8.8)
    fig, (ax1, ax2) = plt.subplots(
        1,
        2,
        figsize=(5.45, 2.75),
        constrained_layout=True,
        gridspec_kw={"width_ratios": [1.22, 1.0]},
    )

    data = [
        pd.to_numeric(
            seeds.loc[seeds["variant"] == variant, "macro_margin_pdppo_vs_validation_selected_static"],
            errors="coerce",
        )
        .dropna()
        .to_numpy(dtype=float)
        for variant in variant_order
    ]
    positions = np.arange(len(data))
    box = ax1.boxplot(
        data,
        vert=False,
        positions=positions,
        widths=0.55,
        patch_artist=True,
        showfliers=False,
        medianprops={"color": "#222222", "linewidth": 1.1},
        whiskerprops={"color": "#686868", "linewidth": 0.8},
        capprops={"color": "#686868", "linewidth": 0.8},
    )
    colors = [PALETTE["blue"], PALETTE["teal"], PALETTE["orange"], PALETTE["purple"]]
    for patch, color in zip(box["boxes"], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.50)
        patch.set_edgecolor("#555555")
        patch.set_linewidth(0.8)
    rng = np.random.default_rng(20260623)
    for idx, values in enumerate(data):
        jitter = rng.normal(0.0, 0.045, size=len(values))
        ax1.scatter(
            values,
            np.full(len(values), positions[idx]) + jitter,
            s=13,
            color=colors[idx % len(colors)],
            edgecolors="white",
            linewidths=0.25,
            alpha=0.82,
            zorder=3,
        )
    ax1.axvline(0.0, color="#5C5C5C", linewidth=0.8, linestyle="--")
    ax1.set_yticks(positions)
    ax1.set_yticklabels(labels)
    ax1.invert_yaxis()
    ax1.set_xlabel("Validation-static macro loss minus PD-PPO loss")
    ax1.set_title("(a) Macro score differences by seed", loc="left")

    delta_summary = summary[summary["variant"] != "full_reference"].copy()
    y = np.arange(len(delta_summary))
    mean = delta_summary["paired_delta_macro_margin_mean_vs_full"].to_numpy(dtype=float)
    lo = delta_summary["paired_delta_macro_margin_ci_low_vs_full"].to_numpy(dtype=float)
    hi = delta_summary["paired_delta_macro_margin_ci_high_vs_full"].to_numpy(dtype=float)
    xerr = np.vstack([mean - lo, hi - mean])
    ax2.errorbar(
        mean,
        y,
        xerr=xerr,
        fmt="o",
        color=PALETTE["teal"],
        ecolor="#555555",
        elinewidth=0.9,
        capsize=2.6,
        markersize=4.2,
    )
    ax2.axvline(0.0, color="#5C5C5C", linewidth=0.8, linestyle="--")
    ax2.set_yticks(y)
    ax2.set_yticklabels([short_label(str(label)) for label in delta_summary["variant_label"]])
    ax2.invert_yaxis()
    ax2.set_xlabel(r"$\Delta$ mean macro margin vs full")
    ax2.set_title("(b) Paired bootstrap 95% CI", loc="left")
    for yi, (_, row) in enumerate(delta_summary.iterrows()):
        anchor = hi[yi] if mean[yi] >= 0 else lo[yi]
        ha = "left" if mean[yi] >= 0 else "right"
        pad = 0.003 if mean[yi] >= 0 else -0.003
        ax2.text(
            anchor + pad,
            yi,
            f"step {int(row['step_win_count'])}/{int(row['complete_seeds'])}",
            va="center",
            ha=ha,
            fontsize=6.8,
            color="#444444",
        )
    xmin = min(float(np.nanmin(lo)) - 0.035, -0.025)
    xmax = max(float(np.nanmax(hi)) + 0.035, 0.025)
    ax2.set_xlim(xmin, xmax)

    save_pdf_png(fig, Path(args.out))
    plt.close(fig)
    print(f"wrote {args.out}.pdf")


if __name__ == "__main__":
    main()
