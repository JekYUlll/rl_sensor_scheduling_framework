#!/usr/bin/env python3
"""Generate final-benchmark diagnostic figures used by the active manuscript."""
from __future__ import annotations

import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from paper_plot_style import PALETTE, apply_paper_style, save_pdf_png

apply_paper_style(base_size=8.2)

COLORS = {
    "staticnorm": PALETTE["teal"],
    "raw": PALETTE["vermillion"],
    "replay": PALETTE["blue"],
    "entropy": PALETTE["purple"],
    "mi": PALETTE["orange"],
    "l1": PALETTE["dark"],
    "text": PALETTE["dark"],
    "light": PALETTE["light"],
    "dark": PALETTE["dark"],
    "gray": PALETTE["gray"],
}


PAPER_DIR = Path(__file__).resolve().parents[1]
ROOT_DIR = PAPER_DIR.parent
AGG_DIR = ROOT_DIR / "reports" / "aggregate"
RUN_ID = (
    "scenebal2_confirm_conf05_117_118_119_120_121_122_123_124_125_126_127_128_"
    "129_130_131_132_133_134_135_136_137_138_139_140"
)
STATICNORM_CSV = AGG_DIR / f"{RUN_ID}_macro_20260621" / "metpair_seed_summary.csv"
RAW_CSV = AGG_DIR / f"{RUN_ID}_raw_macro_20260621" / "metpair_seed_summary.csv"
ACTION_ROWS_CSV = AGG_DIR / "paper_event_type_diagnostics_20260623" / "event_type_action_rows.csv"
OUT_DIR = PAPER_DIR / "figures"

EVENT_ORDER = ["non_event", "particle", "flux", "thermal"]
EVENT_LABELS = ["Non-event", "Particle", "Flux", "Thermal"]
SPECIALIST_ORDER = [
    "radiometer_basic",
    "shielded_thermo_hygro",
    "surface_temp_ir",
    "laser_disdrometer",
    "fc4_flux",
]
SPECIALIST_LABELS = ["Rad.", "Thermo.", "Surface infrared", "Laser", "FC4 flux"]


def load_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def as_float(row: dict[str, str], key: str) -> float:
    try:
        return float(row[key])
    except (KeyError, TypeError, ValueError):
        return float("nan")


def as_bool(row: dict[str, str], key: str) -> bool:
    return str(row.get(key, "")).strip().lower() in {"1", "true", "yes"}


def save_figure(fig: plt.Figure, stem: str) -> None:
    save_pdf_png(fig, OUT_DIR / stem)


def load_action_heatmap(path: Path) -> np.ndarray:
    if not path.exists():
        raise FileNotFoundError(
            f"{path} is required for the behavior heatmap; run "
            "paper/figures/gen_fig_event_type_diagnostics.py first."
        )
    rows = load_rows(path)
    heat = np.full((len(EVENT_ORDER), len(SPECIALIST_ORDER)), np.nan, dtype=float)
    for event_idx, event in enumerate(EVENT_ORDER):
        for sensor_idx, sensor in enumerate(SPECIALIST_ORDER):
            values = [
                as_float(row, "duty")
                for row in rows
                if row.get("event_type") == event and row.get("sensor") == sensor
            ]
            finite = [value for value in values if np.isfinite(value)]
            if finite:
                heat[event_idx, sensor_idx] = float(np.mean(finite))
    return heat


def build_metric_boundary(static_rows: list[dict[str, str]], raw_rows: list[dict[str, str]]) -> None:
    raw_by_seed = {int(row["seed"]): row for row in raw_rows}
    records = []
    for row in static_rows:
        seed = int(row["seed"])
        raw = raw_by_seed[seed]
        records.append(
            {
                "seed": seed,
                "staticnorm_margin": as_float(row, "learned_macro_margin_abs_vs_macro_static_reference"),
                "raw_margin": as_float(raw, "learned_macro_margin_abs_vs_macro_static_reference"),
                "replay_raw_margin": as_float(raw, "replay_macro_margin_abs_vs_static_reference"),
                "staticnorm_gate": as_bool(row, "learned_macro_gate_pass"),
                "raw_gate": as_bool(raw, "learned_macro_gate_pass"),
                "replay_raw_gate": as_bool(raw, "replay_macro_gate_pass"),
            }
        )
    records.sort(key=lambda item: item["seed"])
    seeds = [item["seed"] for item in records]
    x = np.arange(len(records))

    staticnorm_margin = np.array([item["staticnorm_margin"] for item in records])
    raw_margin = np.array([item["raw_margin"] for item in records])
    replay_raw_margin = np.array([item["replay_raw_margin"] for item in records])
    gate_counts = np.array(
        [
            sum(item["staticnorm_gate"] for item in records),
            sum(item["replay_raw_gate"] for item in records),
            sum(item["raw_gate"] for item in records),
        ]
    )
    gate_labels = [
        "Learned\nstatic-ref.\nmacro",
        "Explicit replay\nraw macro",
        "Learned\nraw macro",
    ]

    fig, (ax1, ax2) = plt.subplots(
        1,
        2,
        figsize=(5.35, 2.35),
        constrained_layout=True,
        gridspec_kw={"width_ratios": [1.55, 1.0]},
    )
    ax1.axhline(0.0, color="#555555", linewidth=0.7)
    ax1.bar(
        x - 0.18,
        staticnorm_margin,
        width=0.36,
        color=COLORS["staticnorm"],
        edgecolor="white",
        linewidth=0.35,
        label="Learned, fixed-schedule reference",
    )
    ax1.bar(
        x + 0.18,
        raw_margin,
        width=0.36,
        color=COLORS["raw"],
        edgecolor="white",
        linewidth=0.35,
        label="Learned, raw subtype macro",
    )
    ax1.plot(
        x,
        replay_raw_margin,
        color=COLORS["replay"],
        marker="o",
        markersize=2.9,
        linewidth=1.0,
        label="Explicit replay, raw macro",
    )
    ax1.set_xticks(x[::2])
    ax1.set_xticklabels(seeds[::2], rotation=45, ha="right")
    ax1.set_xlabel("Seed")
    ax1.set_ylabel("Margin vs. fixed schedule")
    ax1.set_title("(a) Macro margin by scoring rule", loc="left")
    ax1.legend(loc="lower left", ncol=1)

    y = np.arange(len(gate_labels))
    colors = [COLORS["staticnorm"], COLORS["replay"], COLORS["raw"]]
    ax2.barh(y, gate_counts, color=colors, edgecolor="white", linewidth=0.4, height=0.58)
    ax2.barh(
        y,
        len(records) - gate_counts,
        left=gate_counts,
        color=COLORS["light"],
        edgecolor="white",
        linewidth=0.4,
        height=0.58,
    )
    ax2.set_yticks(y)
    ax2.set_yticklabels(gate_labels)
    ax2.invert_yaxis()
    ax2.set_xlim(0, len(records))
    ax2.set_xticks([0, 8, 16, 24])
    ax2.set_xlabel("Positive seeds")
    ax2.set_title("(b) Macro-score boundary", loc="left")
    for yi, value in enumerate(gate_counts):
        ax2.text(
            min(value + 0.2, len(records) - 0.1),
            yi,
            f"{value}/{len(records)}",
            va="center",
            ha="left" if value < len(records) else "right",
            fontsize=8.0,
            color=COLORS["text"],
        )
    save_figure(fig, "figure_scenebal2_metric_boundary")


def build_behavior_audit(static_rows: list[dict[str, str]]) -> None:
    records = []
    for row in static_rows:
        records.append(
            {
                "seed": int(row["seed"]),
                "mask_entropy": as_float(row, "behavior_mask_entropy_bits"),
                "transition_entropy": as_float(row, "behavior_transition_entropy_bits"),
                "event_mi": as_float(row, "behavior_event_mask_mi_bits"),
                "event_l1": as_float(row, "behavior_event_sensor_l1"),
                "unique_masks": as_float(row, "behavior_unique_mask_count"),
                "gate": as_bool(row, "behavior_gate_pass"),
                "state_dependent": as_bool(row, "behavior_state_dependent"),
                "fixed_like": as_bool(row, "behavior_fixed_like"),
                "simple_cycle_like": as_bool(row, "behavior_simple_cycle_like"),
            }
        )
    records.sort(key=lambda item: item["seed"])
    mask_entropy = np.array([item["mask_entropy"] for item in records])
    event_mi = np.array([item["event_mi"] for item in records])
    event_l1 = np.array([item["event_l1"] for item in records])
    gate_counts = np.array(
        [
            sum(item["gate"] for item in records),
            sum(item["state_dependent"] for item in records),
            sum(not item["fixed_like"] for item in records),
            sum(not item["simple_cycle_like"] for item in records),
        ]
    )
    gate_labels = ["All gates", "State dep.", "Non-fixed", "Non-cyclic"]
    fig, (ax1, ax2) = plt.subplots(
        1,
        2,
        figsize=(5.35, 2.65),
        constrained_layout=False,
        gridspec_kw={"width_ratios": [1.2, 0.9]},
    )
    fig.subplots_adjust(left=0.090, right=0.970, bottom=0.235, top=0.865, wspace=0.34)
    box_data = [mask_entropy, event_mi, event_l1]
    box = ax1.boxplot(
        box_data,
        patch_artist=True,
        widths=0.55,
        showfliers=True,
        medianprops={"color": COLORS["dark"], "linewidth": 1.25},
        whiskerprops={"color": COLORS["gray"], "linewidth": 0.9},
        capprops={"color": COLORS["gray"], "linewidth": 0.9},
        flierprops={"marker": "o", "markersize": 2.6, "markerfacecolor": COLORS["gray"], "markeredgewidth": 0},
    )
    for patch, color in zip(box["boxes"], [COLORS["entropy"], COLORS["mi"], COLORS["l1"]], strict=True):
        patch.set_facecolor(color)
        patch.set_edgecolor("white")
        patch.set_alpha(0.72)
    rng = np.random.default_rng(7)
    for idx, values in enumerate(box_data, start=1):
        jitter = rng.normal(0.0, 0.035, size=len(values))
        ax1.scatter(
            np.full(len(values), idx, dtype=float) + jitter,
            values,
            s=9,
            color=COLORS["dark"],
            alpha=0.46,
            linewidth=0,
            zorder=3,
        )
    ax1.axhline(0.0, color="#555555", linewidth=0.75, linestyle="--")
    ax1.set_xticks([1, 2, 3])
    ax1.set_xticklabels(["Action\nentropy", "Event-action\nMI", "Event-sensor\nseparation"])
    ax1.set_ylabel("Action-trace statistic")
    ax1.set_title("(a) Distribution over 24 seeds", loc="left")
    ax1.text(
        0.03,
        0.96,
        "All four action-trace checks passed in 24/24 seeds",
        transform=ax1.transAxes,
        ha="left",
        va="top",
        fontsize=7.1,
        color=COLORS["text"],
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.72, "pad": 1.4},
    )

    y = np.arange(len(gate_labels))
    ax2.barh(y, gate_counts, color=COLORS["staticnorm"], edgecolor="white", linewidth=0.4, height=0.58)
    ax2.barh(
        y,
        len(records) - gate_counts,
        left=gate_counts,
        color=COLORS["light"],
        edgecolor="white",
        linewidth=0.4,
        height=0.58,
    )
    ax2.set_yticks(y)
    ax2.set_yticklabels(gate_labels)
    ax2.invert_yaxis()
    ax2.set_xlim(0, len(records))
    ax2.set_xticks([0, 8, 16, 24])
    ax2.set_xlabel("Passing seeds")
    ax2.set_title("(b) Audit gates", loc="left")
    for yi, value in enumerate(gate_counts):
        ax2.text(
            min(value + 0.25, len(records) - 0.2),
            yi,
            f"{value}/{len(records)}",
            va="center",
            ha="left" if value < len(records) else "right",
            fontsize=7.8,
            color=COLORS["text"],
        )
    save_figure(fig, "figure_scenebal2_behavior_audit")
    save_figure(fig, "figure_behavior_audit")


def main() -> None:
    static_rows = load_rows(STATICNORM_CSV)
    raw_rows = load_rows(RAW_CSV)
    if len(static_rows) != 24 or len(raw_rows) != 24:
        raise ValueError("Expected 24 final-benchmark rows in both aggregate CSVs")
    build_metric_boundary(static_rows, raw_rows)
    build_behavior_audit(static_rows)


if __name__ == "__main__":
    main()
