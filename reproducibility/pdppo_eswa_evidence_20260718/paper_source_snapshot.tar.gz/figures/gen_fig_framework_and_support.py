#!/usr/bin/env python3
"""Generate framework and support-evidence figures for the ESWA manuscript."""
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.patches as patches

from paper_plot_style import PALETTE, apply_paper_style, save_pdf_png


apply_paper_style(base_size=8.7)

PAPER_DIR = Path(__file__).resolve().parents[1]
OUT_DIR = PAPER_DIR / "figures"


def rounded_box(
    ax: plt.Axes,
    xy: tuple[float, float],
    wh: tuple[float, float],
    label: str,
    color: str,
    *,
    text_color: str = "#2F2F2F",
    lw: float = 1.1,
) -> None:
    x, y = xy
    w, h = wh
    box = patches.FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle="round,pad=0.012,rounding_size=0.018",
        facecolor=color,
        edgecolor="#56606A",
        linewidth=lw,
    )
    ax.add_patch(box)
    ax.text(x + w / 2, y + h / 2, label, ha="center", va="center", color=text_color, fontsize=7.2)


def arrow(
    ax: plt.Axes,
    start: tuple[float, float],
    end: tuple[float, float],
    *,
    color: str = "#4A4A4A",
    dashed: bool = False,
    lw: float = 1.0,
    rad: float = 0.0,
) -> None:
    ax.annotate(
        "",
        xy=end,
        xytext=start,
        arrowprops={
            "arrowstyle": "-|>",
            "lw": lw,
            "color": color,
            "linestyle": "--" if dashed else "-",
            "shrinkA": 2,
            "shrinkB": 2,
            "connectionstyle": f"arc3,rad={rad}",
        },
    )


def generate_framework() -> None:
    """Draw the three-stage training and evaluation protocol."""
    apply_paper_style(base_size=8.7)
    fig, ax = plt.subplots(figsize=(6.8, 3.35))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    stages = [
        ("Stage 1\nForecaster fitting", "0--24,500", 0.035, 0.450, 0.285, 0.415, "#F3F7FB", PALETTE["blue"]),
        ("Stage 2\nPolicy training", "24,500--59,500", 0.360, 0.450, 0.285, 0.415, "#F2FAF6", PALETTE["teal"]),
        ("Stage 3\nFinal evaluation", "64,750--70,000", 0.685, 0.450, 0.285, 0.415, "#FFF8E8", PALETTE["orange"]),
    ]
    for title, partition, x, y, w, h, fill, accent in stages:
        ax.add_patch(
            patches.FancyBboxPatch(
                (x, y),
                w,
                h,
                boxstyle="round,pad=0.010,rounding_size=0.018",
                facecolor=fill,
                edgecolor="#CED4DA",
                linewidth=0.8,
            )
        )
        header_h = 0.090
        ax.add_patch(patches.Rectangle((x, y + h - header_h), w, header_h, facecolor=accent, edgecolor="none", alpha=0.95))
        title_one_line = title.replace("\n", "  ")
        ax.text(x + 0.014, y + h - 0.027, title_one_line, ha="left", va="center", fontsize=7.4, weight="bold", color="white")
        ax.text(x + 0.014, y + h - 0.070, partition, ha="left", va="center", fontsize=6.8, color="white")

    def box(x: float, y: float, w: float, h: float, label: str, fill: str) -> None:
        rounded_box(ax, (x, y), (w, h), label, fill, text_color="#2B2B2B", lw=0.8)

    top_y = 0.675
    low_y = 0.548
    box(0.070, top_y, 0.105, 0.075, "Truth\nsequence", "#DCEAF7")
    box(0.205, top_y, 0.080, 0.075, "Fixed\nforecaster", "#DCEAF7")
    box(0.070, low_y, 0.215, 0.078, "Learned, fixed, rule-based, and\nsupplementary references", "#E9F2FA")
    arrow(ax, (0.175, top_y + 0.038), (0.205, top_y + 0.038), color=PALETTE["blue"])
    arrow(ax, (0.178, low_y + 0.077), (0.208, top_y), color=PALETTE["blue"], rad=0.12)

    box(0.392, top_y, 0.090, 0.075, "Simulator\nrollouts", "#DDF2EA")
    box(0.515, top_y, 0.092, 0.075, "Forecaster\nloss", "#DDF2EA")
    box(0.392, low_y, 0.092, 0.078, "Training\nlabels", "#EFF8F3")
    box(0.515, low_y, 0.092, 0.078, "Masked PPO\npolicy", "#EFF8F3")
    arrow(ax, (0.482, top_y + 0.038), (0.515, top_y + 0.038), color=PALETTE["teal"])
    arrow(ax, (0.438, top_y), (0.438, low_y + 0.078), color=PALETTE["teal"])
    arrow(ax, (0.484, low_y + 0.039), (0.515, low_y + 0.039), color=PALETTE["teal"])
    arrow(ax, (0.608, low_y + 0.039), (0.608, top_y), color=PALETTE["teal"], rad=-0.18)

    box(0.715, top_y, 0.100, 0.075, "Held-out\nrollouts", "#FFF2D8")
    box(0.840, top_y, 0.098, 0.075, "Forecast loss\n+ macro score", "#FFF2D8")
    box(0.715, low_y, 0.100, 0.078, "Fixed and\nrule schedules", "#FFF7E6")
    box(0.840, low_y, 0.098, 0.078, "Action-trace\nchecks", "#FFF7E6")
    arrow(ax, (0.815, top_y + 0.038), (0.840, top_y + 0.038), color=PALETTE["orange"])
    arrow(ax, (0.765, low_y + 0.078), (0.765, top_y), color=PALETTE["orange"])
    arrow(ax, (0.815, low_y + 0.039), (0.840, low_y + 0.039), color=PALETTE["orange"])

    arrow(ax, (0.285, top_y + 0.038), (0.392, top_y + 0.038), color=PALETTE["gray"], lw=0.9, rad=0.08)
    arrow(ax, (0.285, low_y + 0.039), (0.515, top_y + 0.038), color=PALETTE["gray"], dashed=True, lw=0.85, rad=-0.18)
    arrow(ax, (0.607, low_y + 0.039), (0.715, top_y + 0.038), color=PALETTE["gray"], lw=0.9, rad=0.08)
    arrow(ax, (0.607, top_y + 0.038), (0.840, top_y + 0.038), color=PALETTE["gray"], dashed=True, lw=0.85, rad=-0.10)

    # Validation partition for fixed schedules.
    ax.add_patch(
        patches.FancyBboxPatch(
            (0.205, 0.205),
            0.590,
            0.135,
            boxstyle="round,pad=0.010,rounding_size=0.016",
            facecolor="#F7F7F7",
            edgecolor="#D2D2D2",
            linewidth=0.75,
        )
    )
    ax.text(0.225, 0.292, "Validation partition for fixed schedules", fontsize=8.2, weight="bold", ha="left", va="center", color="#3A3A3A")
    ax.text(0.225, 0.245, "59,500--64,750, choose fixed schedules and metric normalizers; no final test labels", fontsize=7.4, ha="left", va="center", color="#3A3A3A")
    arrow(ax, (0.500, 0.450), (0.500, 0.340), color=PALETTE["gray"], dashed=True, lw=0.85)
    arrow(ax, (0.795, 0.273), (0.840, 0.575), color=PALETTE["gray"], dashed=True, lw=0.85, rad=-0.16)

    save_pdf_png(fig, OUT_DIR / "figure_pdppo_framework_image2")
    plt.close(fig)


def main() -> None:
    generate_framework()
    # The mechanism-ablation figure is generated by
    # gen_fig_mechanism_continuous.py from the 24-seed continuous-margin report.
    # Keep this script scoped to the framework figure so reruns cannot overwrite
    # the current mechanism evidence with the historical six-seed diagnostic.


if __name__ == "__main__":
    main()
