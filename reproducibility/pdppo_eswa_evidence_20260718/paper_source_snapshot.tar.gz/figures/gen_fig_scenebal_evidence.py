#!/usr/bin/env python3
"""Generate the validation-frozen seed-level evidence figure."""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from paper_plot_style import PALETTE, apply_paper_style, save_pdf_png


COLORS = {
    "step": PALETTE["teal"],
    "macro": PALETTE["vermillion"],
    "threshold": PALETTE["dark"],
    "text": PALETTE["dark"],
}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed-csv", type=Path, required=True)
    parser.add_argument("--out-prefix", type=Path, required=True)
    args = parser.parse_args()

    rows = pd.read_csv(args.seed_csv).copy()
    rows["step_margin"] = pd.to_numeric(rows["step_margin_pdppo_vs_validation_selected_static"], errors="coerce")
    rows["macro_margin"] = pd.to_numeric(rows["macro_margin_pdppo_vs_validation_selected_static"], errors="coerce")
    rows["reference_step_loss"] = pd.to_numeric(rows["validation_selected_static_step_loss"], errors="coerce")
    rows = rows.dropna(subset=["seed", "step_margin", "macro_margin", "reference_step_loss"]).sort_values("step_margin")
    if rows.empty:
        raise ValueError("No complete seed rows.")

    thresholds = np.maximum(0.001, 0.002 * rows["reference_step_loss"].to_numpy(dtype=float))
    records = rows.reset_index(drop=True)
    x = np.arange(len(records))
    step = records["step_margin"].to_numpy(dtype=float)
    macro = records["macro_margin"].to_numpy(dtype=float)
    seeds = records["seed"].astype(int).to_numpy()

    apply_paper_style(base_size=8.8)
    fig, (ax1, ax2) = plt.subplots(
        1,
        2,
        figsize=(5.35, 2.4),
        constrained_layout=True,
        gridspec_kw={"width_ratios": [1.55, 1.0]},
    )

    ax1.scatter(x, step, s=18, color=COLORS["step"], edgecolor="white", linewidth=0.35, label="Step loss", zorder=3)
    ax1.scatter(x, macro, s=20, marker="s", color=COLORS["macro"], edgecolor="white", linewidth=0.35, label="Macro score", zorder=3)
    ax1.axhspan(float(np.min(thresholds)), float(np.max(thresholds)), color=COLORS["threshold"], alpha=0.13, label="Step threshold", zorder=0)
    ax1.axhline(0.0, color="#555555", linewidth=0.7)
    tick_idx = list(range(0, len(seeds), 4))
    if tick_idx[-1] != len(seeds) - 1:
        tick_idx.append(len(seeds) - 1)
    ax1.set_xticks(tick_idx)
    ax1.set_xticklabels([seeds[idx] for idx in tick_idx], rotation=45, ha="right")
    ax1.set_xlabel("Seed, sorted by step margin")
    ax1.set_ylabel("Validation-static loss minus PD-PPO loss")
    ax1.set_title("(a) Paired margins by seed", loc="left")
    ax1.legend(loc="upper left", fontsize=6.6, frameon=False, handletextpad=0.4)

    values = [step, macro]
    labels = ["Step loss", "Macro score"]
    colors = [COLORS["step"], COLORS["macro"]]
    box = ax2.boxplot(
        values,
        positions=[1, 2],
        widths=0.5,
        patch_artist=True,
        showfliers=False,
        medianprops={"color": COLORS["text"], "linewidth": 1.0},
        boxprops={"linewidth": 0.8, "color": COLORS["text"]},
        whiskerprops={"linewidth": 0.8, "color": COLORS["text"]},
        capprops={"linewidth": 0.8, "color": COLORS["text"]},
    )
    for patch, color in zip(box["boxes"], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.32)
    rng = np.random.default_rng(17)
    for position, value, color in zip([1, 2], values, colors):
        ax2.scatter(position + rng.normal(0.0, 0.045, size=len(value)), value, s=10, color=color, edgecolor="white", linewidth=0.25, alpha=0.9, zorder=3)
    ax2.axhline(0.0, color="#555555", linewidth=0.7)
    ax2.set_xticks([1, 2])
    ax2.set_xticklabels(labels)
    ax2.set_ylabel("Validation-static loss minus PD-PPO loss")
    ax2.set_title("(b) Paired distributions", loc="left")
    ax2.text(0.98, 0.05, "positive favors PD-PPO", transform=ax2.transAxes, ha="right", va="bottom", fontsize=6.8, color=COLORS["text"])

    save_pdf_png(fig, args.out_prefix)
    plt.close(fig)


if __name__ == "__main__":
    main()
