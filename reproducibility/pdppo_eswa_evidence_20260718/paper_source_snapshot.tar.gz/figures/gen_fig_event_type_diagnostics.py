#!/usr/bin/env python3
"""Build event-type diagnostics and reproducibility tables for the manuscript."""
from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from paper_plot_style import PALETTE, apply_paper_style, save_pdf_png

apply_paper_style()

PAPER_DIR = Path(__file__).resolve().parents[1]
ROOT_DIR = PAPER_DIR.parent
REPORT_DIR = ROOT_DIR / "reports"
OUT_TABLE_DIR = PAPER_DIR / "tables"
OUT_FIG_DIR = PAPER_DIR / "figures"
OUT_AGG_DIR = ROOT_DIR / "reports" / "aggregate" / "paper_event_type_diagnostics_20260623"

RUN_PREFIX = "v31_metpair_backbone_context_ortholinear_balancedobjective_scenebal2"
RUN_SUFFIX = "h075ctxolscbal2_20260621"
EVAL_DIR = "eval_router_conf05_scenebal2_20260621"
STATIC_DIR = "replay_gate_explicit_static_noguard"
SEEDS = tuple(range(117, 141))

SENSOR_IDS = [
    "met_station_core",
    "radiometer_basic",
    "shielded_thermo_hygro",
    "surface_temp_ir",
    "laser_disdrometer",
    "fc4_flux",
]
SENSOR_LABELS = {
    "met_station_core": "Weather backbone",
    "radiometer_basic": "Radiometer",
    "shielded_thermo_hygro": "Thermo-hygrometer",
    "surface_temp_ir": "Surface infrared sensor",
    "laser_disdrometer": "Laser disdrometer",
    "fc4_flux": "FC4 flux sensor",
}
EVENT_IDS = {
    1: "particle",
    2: "flux",
    3: "thermal",
}
EVENT_LABELS = {
    "particle": "Particle",
    "flux": "Flux",
    "thermal": "Thermal",
}
POLICY_FILES = {
    "pdppo": "rollout_custom_ppo.npz",
    "fixed": "rollout_validation_selected_static.npz",
    "round_robin": "rollout_round_robin.npz",
    "aoi": "rollout_aoi.npz",
    "random": "rollout_random.npz",
}
POLICY_LABELS = {
    "pdppo": "PD-PPO",
    "fixed": "Fixed schedule",
    "round_robin": "Round-robin",
    "aoi": "AoI",
    "random": "Random",
    "best_rule": "Best rule-based",
}


def run_dir(seed: int) -> Path:
    return REPORT_DIR / f"{RUN_PREFIX}_seed{seed}_{RUN_SUFFIX}"


def latex_escape(text: object) -> str:
    value = str(text)
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    for old, new in replacements.items():
        value = value.replace(old, new)
    return value


def mean_se(values: pd.Series) -> tuple[float, float]:
    arr = pd.to_numeric(values, errors="coerce").to_numpy(dtype=float)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return float("nan"), float("nan")
    if arr.size == 1:
        return float(arr[0]), 0.0
    return float(np.mean(arr)), float(np.std(arr, ddof=1) / np.sqrt(arr.size))


def fmt_mean_se(values: pd.Series) -> str:
    mean, se = mean_se(values)
    if not np.isfinite(mean):
        return "--"
    return f"{mean:.3f} $\\pm$ {se:.3f}"


def norm_from_static_candidates(path: Path) -> dict[str, float]:
    table = pd.read_csv(path)
    out: dict[str, float] = {}
    for event in EVENT_LABELS:
        col = f"oracle_loss_subtype_{event}"
        values = pd.to_numeric(table[col], errors="coerce").to_numpy(dtype=float)
        values = values[np.isfinite(values) & (values > 0)]
        if values.size == 0:
            raise ValueError(f"No static normalizer values in {path} column {col}")
        out[event] = float(np.median(values))
    return out


def load_policy_losses(seed: int, policy_key: str, normalizers: dict[str, float]) -> list[dict[str, object]]:
    base = run_dir(seed)
    truth = pd.read_csv(base / "truth_v31_split.csv", usecols=["event_subtype_id"])
    subtype_ids = truth["event_subtype_id"].to_numpy(dtype=int)
    data = np.load(base / EVAL_DIR / POLICY_FILES[policy_key], allow_pickle=False)
    losses = np.asarray(data["oracle_losses"], dtype=float).reshape(-1)
    step_indices = np.asarray(data["step_indices"], dtype=int).reshape(-1)
    finite = np.isfinite(losses)
    valid = (step_indices >= 0) & (step_indices < subtype_ids.size) & finite
    event_for_step = np.zeros(step_indices.size, dtype=int)
    event_for_step[valid] = subtype_ids[step_indices[valid]]
    rows: list[dict[str, object]] = []
    for event_id, event in EVENT_IDS.items():
        mask = valid & (event_for_step == int(event_id))
        raw_loss = float(np.mean(losses[mask])) if np.any(mask) else float("nan")
        norm_loss = raw_loss / normalizers[event] if np.isfinite(raw_loss) else float("nan")
        rows.append(
            {
                "seed": seed,
                "policy": policy_key,
                "event_type": event,
                "raw_loss": raw_loss,
                "norm_loss": norm_loss,
                "steps": int(np.sum(mask)),
            }
        )
    return rows


def load_custom_action_rows(seed: int) -> list[dict[str, object]]:
    base = run_dir(seed)
    truth = pd.read_csv(base / "truth_v31_split.csv", usecols=["event_subtype_id"])
    subtype_ids = truth["event_subtype_id"].to_numpy(dtype=int)
    data = np.load(base / EVAL_DIR / "rollout_custom_ppo.npz", allow_pickle=False)
    selected = np.asarray(data["selected_masks"], dtype=float)
    step_indices = np.asarray(data["step_indices"], dtype=int).reshape(-1)
    valid = (step_indices >= 0) & (step_indices < subtype_ids.size)
    event_for_step = np.zeros(step_indices.size, dtype=int)
    event_for_step[valid] = subtype_ids[step_indices[valid]]
    rows: list[dict[str, object]] = []
    for event_id, event_label in [(0, "non_event"), (1, "particle"), (2, "flux"), (3, "thermal")]:
        mask = valid & (event_for_step == int(event_id))
        if not np.any(mask):
            continue
        for sensor_idx, sensor_id in enumerate(SENSOR_IDS):
            rows.append(
                {
                    "seed": seed,
                    "event_type": event_label,
                    "sensor": sensor_id,
                    "duty": float(np.mean(selected[mask, sensor_idx])),
                    "steps": int(np.sum(mask)),
                }
            )
    return rows


def collect() -> tuple[pd.DataFrame, pd.DataFrame, list[dict[str, object]], list[dict[str, object]]]:
    loss_rows: list[dict[str, object]] = []
    action_rows: list[dict[str, object]] = []
    static_rows: list[dict[str, object]] = []
    metadata_rows: list[dict[str, object]] = []
    for seed in SEEDS:
        base = run_dir(seed)
        if not base.exists():
            raise FileNotFoundError(base)
        metadata = json.loads((base / EVAL_DIR / "v2_ppo_metadata.json").read_text(encoding="utf-8"))
        root_metadata = json.loads((base / "v2_ppo_metadata.json").read_text(encoding="utf-8"))
        metadata_rows.append({"seed": seed, "metadata": metadata, "root_metadata": root_metadata})
        selected = metadata["selected_static_reference"]
        static_rows.append(
            {
                "seed": seed,
                "action_idx": int(selected["action_idx"]),
                "sensor_ids": str(selected["sensor_ids"]),
                "score": float(selected["candidate_prior_oracle_loss_macro_subtype_event_staticnorm"]),
                "power_mean": float(selected["candidate_prior_power_mean"]),
            }
        )
        # The macro definition fixes subtype denominators on validation windows.
        normalizers = norm_from_static_candidates(base / "validation_static_candidates.csv")
        for policy_key in POLICY_FILES:
            loss_rows.extend(load_policy_losses(seed, policy_key, normalizers))
        action_rows.extend(load_custom_action_rows(seed))
    loss_df = pd.DataFrame(loss_rows)
    action_df = pd.DataFrame(action_rows)
    static_df = pd.DataFrame(static_rows)

    rule_df = loss_df[loss_df["policy"].isin(["round_robin", "aoi", "random"])]
    best_rule = []
    for seed, seed_df in rule_df.groupby("seed"):
        macro = seed_df.groupby("policy", as_index=False)["norm_loss"].mean().sort_values("norm_loss")
        best_policy = str(macro.iloc[0]["policy"])
        rows = seed_df[seed_df["policy"] == best_policy].copy()
        rows["policy"] = "best_rule"
        best_rule.append(rows)
    if best_rule:
        loss_df = pd.concat([loss_df, *best_rule], ignore_index=True)
    return loss_df, action_df, static_rows, metadata_rows


def write_action_space_table(static_df: pd.DataFrame) -> None:
    first_candidates = pd.read_csv(run_dir(SEEDS[0]) / "validation_static_candidates.csv")
    counts = Counter(static_df["action_idx"].astype(int).tolist())
    role = {
        0: "Backbone only",
        1: "Radiation context",
        2: "Non-event weather context",
        3: "Thermal-event specialist",
        4: "Particle-event specialist",
        5: "Flux-event specialist",
    }
    rows = []
    for _, item in first_candidates.sort_values("action_idx").iterrows():
        action_idx = int(item["action_idx"])
        sensors = [SENSOR_LABELS.get(part, part) for part in str(item["sensor_ids"]).split("|")]
        rows.append(
            rf"    {action_idx} & {latex_escape(' + '.join(sensors))} & {item['power_mean']:.2f} & {latex_escape(role[action_idx])} & {counts[action_idx]}/24 \\"
        )
    content = "\n".join(
        [
            r"\begin{table}[htbp]",
            r"  \centering",
            r"  \caption{Executable sensor choices in the final one-specialist benchmark.}",
            r"  \label{tab:action_space_instantiation}",
            r"  \footnotesize",
            r"  \setlength{\tabcolsep}{3.0pt}",
            r"  \begin{tabular}{@{}c p{0.38\linewidth} c p{0.24\linewidth} c@{}}",
            r"    \toprule",
            r"    Id & Executed channels & Power & Interpretation & Fixed selections \\",
            r"    \midrule",
            *rows,
            r"    \bottomrule",
            r"  \end{tabular}",
            r"  \vspace{0.4ex}",
            "",
            r"  \noindent\footnotesize",
            r"  Every action includes the weather backbone. Fixed selections are",
            r"  validation-selected fixed schedules over the 24 final test seeds.",
            r"\end{table}",
            "",
        ]
    )
    (OUT_TABLE_DIR / "action_space_instantiation.tex").write_text(content, encoding="utf-8")


def write_observability_table() -> None:
    rows = [
        (
            "State estimate and last observations",
            "Estimator and channel history",
            "Yes",
            "Policy input and fixed forecaster input",
        ),
        (
            "Observation mask and AoI/freshness",
            "Runtime observation log",
            "Yes",
            "Policy input; also used by rule-based baselines",
        ),
        (
            "Previous mask and warm-up state",
            "Scheduler runtime",
            "Yes",
            "Feasibility mask and switching/minimum-duration accounting",
        ),
        (
            "Station-side event-context proxies",
            "Noisy lead signals generated before event onset",
            "Yes",
            "Policy input; not final-test labels",
        ),
        (
            "Event-type labels",
            "Simulator truth sequence",
            "No",
            "Training auxiliary labels and diagnostic grouping only",
        ),
        (
            "Future target values",
            "Simulator truth sequence",
            "No",
            "Fixed-forecaster fitting, reward scoring, and final evaluation",
        ),
        (
            "Metric normalizers and selected fixed schedule",
            "Validation partition",
            "No",
            "Reference selection and metric normalization only",
        ),
    ]
    body = [
        rf"    {latex_escape(name)} & {latex_escape(source)} & {online} & {latex_escape(use)} \\"
        for name, source, online, use in rows
    ]
    content = "\n".join(
        [
            r"\begin{table}[htbp]",
            r"  \centering",
            r"  \caption{Online availability of scheduler inputs and diagnostic labels.}",
            r"  \label{tab:online_observability_audit}",
            r"  \footnotesize",
            r"  \setlength{\tabcolsep}{3pt}",
            r"  \begin{tabular}{@{}p{0.25\linewidth}p{0.29\linewidth}c p{0.29\linewidth}@{}}",
            r"    \toprule",
            r"    Quantity & Source & Online & Use in the protocol \\",
            r"    \midrule",
            *body,
            r"    \bottomrule",
            r"  \end{tabular}",
            r"\end{table}",
            "",
        ]
    )
    (OUT_TABLE_DIR / "online_observability_audit.tex").write_text(content, encoding="utf-8")


def write_reproducibility_table(metadata_rows: list[dict[str, object]]) -> None:
    metadata = metadata_rows[0]["metadata"]
    root_metadata = metadata_rows[0]["root_metadata"]
    custom = metadata["custom_ppo"]
    constraints = metadata["constraints"]
    partition = metadata["partition_protocol"]
    event_design = metadata["truth_event_design"]
    rows = [
        ("Final seeds", "117--140"),
        ("Truth length", "70,000 hourly epochs per seed"),
        ("Chronological partitions", "[0,24500) forecaster fitting; [24500,59500) policy learning; [59500,64750) fixed-schedule selection; [64750,70000) final test"),
        ("Forecast lookback / horizon", f"{metadata['lookback']} / {metadata['horizon']} epochs"),
        ("Evaluation rollouts", f"{metadata['eval_rollouts']} rollouts, {metadata['eval_steps']} steps each"),
        ("Candidate masks", str(custom["candidate_count"])),
        ("Required channel", "weather backbone"),
        ("Power / startup limits", f"{constraints['per_step_budget']:.2f} / {constraints['startup_peak_budget']:.2f}"),
        ("Policy timesteps", f"{custom['total_timesteps']:,}"),
        ("PPO rollout / batch / epochs", f"{custom['n_steps']} / {custom['batch_size']} / {custom['n_epochs']}"),
        ("Actor/critic network", "candidate-mask embeddings; 32-dim action embeddings; 128 hidden units; actor and critic conditioned on event-context features"),
        ("Learning rate, discount, GAE", f"{custom['learning_rate']}, {custom['gamma']}, {custom['gae_lambda']}"),
        ("Clip, entropy, value coef.", f"{custom['clip_range']}, {custom['ent_coef']}, {custom['vf_coef']}"),
        (
            "Imitation and auxiliary weights",
            rf"$\beta_{{\mathrm{{BC}}}}={custom['awbc_coef']}$; "
            rf"$\beta_{{\mathrm{{event}}}}={custom['subtype_aux_coef']}$; guide prior not used",
        ),
        ("Minimum on-time and switch cost", f"{metadata['reward_shaping']['min_dwell_steps']} epochs; {metadata['reward_shaping']['lambda_switch']}"),
        ("Fixed-schedule selection score", "event-regime macro loss normalized by fixed schedules"),
        ("Event-type mix", f"particle/flux/thermal = {event_design['event_subtype_particle_prob']:.2f}/{event_design['event_subtype_flux_prob']:.2f}/{event_design['event_subtype_thermal_prob']:.2f}"),
        ("Event coverage target", f"{event_design['blowing_snow_event_coverage']:.2f}"),
        ("Behavior-cloning pretraining", "10,000 steps; 18 epochs; batch size 256"),
        ("Fixed forecaster architecture", "residual TCN, 3 levels, 64 channels, kernel size 3, dropout 0.05"),
        ("Fixed forecaster pretraining", f"{metadata['oracle_rollouts_per_policy']} rollouts per policy; {metadata['oracle_pretrain_rollout_summary']['total_steps']:,} steps"),
        ("Normalization", "forecaster input/target scales fitted before policy updates; fixed-schedule reference scales fitted on validation windows only"),
        ("Checkpoint/schedule selection", "final policy checkpoint fixed after policy learning; fixed schedule selected by lowest validation macro score"),
        ("Computation", "GPU optimization; metrics computed from held-out rollouts"),
    ]
    body = []
    for k, v in rows:
        if k == "Imitation and auxiliary weights":
            body.append(rf"    {latex_escape(k)} & {v} \\")
        else:
            body.append(rf"    {latex_escape(k)} & {latex_escape(v)} \\")
    content = "\n".join(
        [
            r"\begin{table}[htbp]",
            r"  \centering",
            r"  \caption{Main protocol and PD-PPO hyperparameters for the final benchmark.}",
            r"  \label{tab:main_protocol_hyperparameters}",
            r"  \scriptsize",
            r"  \renewcommand{\arraystretch}{0.88}",
            r"  \setlength{\tabcolsep}{3.2pt}",
            r"  \begin{tabular}{@{}p{0.38\linewidth}p{0.55\linewidth}@{}}",
            r"    \toprule",
            r"    Item & Value \\",
            r"    \midrule",
            *body,
            r"    \bottomrule",
            r"  \end{tabular}",
            r"  \vspace{0.2ex}",
            "",
            r"  \noindent\scriptsize",
            r"  Partitions are fixed before final testing; fixed-schedule selection",
            r"  and metric normalizers use only the validation partition.",
            r"\end{table}",
            "",
        ]
    )
    (OUT_TABLE_DIR / "main_protocol_hyperparameters.tex").write_text(content, encoding="utf-8")


def write_static_selection_table(static_df: pd.DataFrame) -> None:
    grouped = static_df.groupby(["action_idx", "sensor_ids"], as_index=False).agg(
        seeds=("seed", "count"),
        mean_score=("score", "mean"),
        mean_power=("power_mean", "mean"),
    )
    grouped = grouped.sort_values(["seeds", "action_idx"], ascending=[False, True])
    rows = []
    for _, item in grouped.iterrows():
        sensors = " + ".join(SENSOR_LABELS.get(part, part) for part in str(item["sensor_ids"]).split("|"))
        rows.append(
            rf"    {int(item['action_idx'])} & {latex_escape(sensors)} & {int(item['seeds'])}/24 & {item['mean_score']:.3f} & {item['mean_power']:.2f} \\"
        )
    content = "\n".join(
        [
            r"\begin{table}[htbp]",
            r"  \centering",
            r"  \caption{Validation-selected fixed schedules over the final seeds.}",
            r"  \label{tab:static_mask_selection_summary}",
            r"  \footnotesize",
            r"  \begin{tabular}{@{}c p{0.40\linewidth} c c c@{}}",
            r"    \toprule",
            r"    Id & Fixed channels & Seeds & Mean validation score & Power \\",
            r"    \midrule",
            *rows,
            r"    \bottomrule",
            r"  \end{tabular}",
            r"  \vspace{0.4ex}",
            "",
            r"  \noindent\footnotesize",
            r"  Lower validation score is better. The fixed schedule is selected on",
            r"  validation windows and then replayed unchanged on final-test",
            r"  windows.",
            r"\end{table}",
            "",
        ]
    )
    (OUT_TABLE_DIR / "static_mask_selection_summary.tex").write_text(content, encoding="utf-8")


def write_event_loss_table(loss_df: pd.DataFrame) -> None:
    rows = []
    for event in ["particle", "flux", "thermal"]:
        event_df = loss_df[loss_df["event_type"] == event]
        pdppo = event_df[event_df["policy"] == "pdppo"].set_index("seed")["norm_loss"]
        fixed = event_df[event_df["policy"] == "fixed"].set_index("seed")["norm_loss"]
        best_rule = event_df[event_df["policy"] == "best_rule"].set_index("seed")["norm_loss"]
        margin = fixed - pdppo
        rows.append(
            {
                "event": EVENT_LABELS[event],
                "pdppo": fmt_mean_se(pdppo),
                "fixed": fmt_mean_se(fixed),
                "best_rule": fmt_mean_se(best_rule),
                "margin": fmt_mean_se(margin),
                "positive": int(np.sum(margin > 0)),
            }
        )
    macro_records = []
    for seed, seed_df in loss_df.groupby("seed"):
        for policy in ["pdppo", "fixed", "best_rule"]:
            macro_records.append(
                {
                    "seed": seed,
                    "policy": policy,
                    "norm_loss": float(seed_df[seed_df["policy"] == policy]["norm_loss"].mean()),
                }
            )
    macro_df = pd.DataFrame(macro_records)
    pdppo = macro_df[macro_df["policy"] == "pdppo"].set_index("seed")["norm_loss"]
    fixed = macro_df[macro_df["policy"] == "fixed"].set_index("seed")["norm_loss"]
    best_rule = macro_df[macro_df["policy"] == "best_rule"].set_index("seed")["norm_loss"]
    margin = fixed - pdppo
    rows.append(
        {
            "event": "Macro average",
            "pdppo": fmt_mean_se(pdppo),
            "fixed": fmt_mean_se(fixed),
            "best_rule": fmt_mean_se(best_rule),
            "margin": fmt_mean_se(margin),
            "positive": int(np.sum(margin > 0)),
        }
    )
    body = [
        rf"    {latex_escape(row['event'])} & {row['pdppo']} & {row['fixed']} & {row['best_rule']} & {row['margin']} & {row['positive']}/24 \\"
        for row in rows
    ]
    content = "\n".join(
        [
            r"\begin{table}[htbp]",
            r"  \centering",
            r"  \caption{Forecast loss by event type on final test rollouts.}",
            r"  \label{tab:event_type_loss_decomposition}",
            r"  \scriptsize",
            r"  \setlength{\tabcolsep}{2pt}",
            r"  \begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}lccccc@{}}",
            r"    \toprule",
            r"    Event type & PD-PPO & Fixed schedule & Best rule & Diff. vs fixed & Positive \\",
            r"    \midrule",
            *body,
            r"    \bottomrule",
            r"  \end{tabular*}",
            r"  \vspace{0.4ex}",
            "",
            r"  \noindent\footnotesize",
            r"  Entries are losses normalized by fixed-schedule references, mean $\pm$ standard error",
            r"  over 24 seeds. The event type rows are diagnostic. The main claim is the",
            r"  held-out macro and step-loss comparison, not per-event dominance across all seeds.",
            r"\end{table}",
            "",
        ]
    )
    (OUT_TABLE_DIR / "event_type_loss_decomposition.tex").write_text(content, encoding="utf-8")


def plot_event_diagnostics(loss_df: pd.DataFrame, action_df: pd.DataFrame) -> None:
    event_order = ["non_event", "particle", "flux", "thermal"]
    event_names = ["Non-event", "Particle", "Flux", "Thermal"]
    specialist_order = [
        "radiometer_basic",
        "shielded_thermo_hygro",
        "surface_temp_ir",
        "laser_disdrometer",
        "fc4_flux",
    ]
    specialist_names = ["Radiometer", "Thermo.", "Surface infrared", "Laser", "FC4 flux"]
    heat = np.zeros((len(event_order), len(specialist_order)), dtype=float)
    for i, event in enumerate(event_order):
        for j, sensor in enumerate(specialist_order):
            values = action_df[(action_df["event_type"] == event) & (action_df["sensor"] == sensor)]["duty"]
            heat[i, j] = float(values.mean()) if not values.empty else np.nan

    margin_rows = []
    for seed, seed_df in loss_df.groupby("seed"):
        fixed = seed_df[seed_df["policy"] == "fixed"].set_index("event_type")["norm_loss"]
        pdppo = seed_df[seed_df["policy"] == "pdppo"].set_index("event_type")["norm_loss"]
        for event in ["particle", "flux", "thermal"]:
            margin_rows.append({"event": EVENT_LABELS[event], "margin": float(fixed[event] - pdppo[event])})
        margin_rows.append({"event": "Macro", "margin": float(np.mean(fixed - pdppo))})
    margin_df = pd.DataFrame(margin_rows)

    fig, (ax1, ax2) = plt.subplots(
        1,
        2,
        figsize=(5.35, 2.65),
        constrained_layout=True,
        gridspec_kw={"width_ratios": [1.15, 1.0]},
    )
    im = ax1.imshow(heat, vmin=0.0, vmax=1.0, cmap="YlGnBu", aspect="auto")
    ax1.set_xticks(np.arange(len(specialist_names)))
    ax1.set_xticklabels(specialist_names, rotation=35, ha="right")
    ax1.set_yticks(np.arange(len(event_names)))
    ax1.set_yticklabels(event_names)
    ax1.set_title("(a) Specialist use by event type", loc="left")
    for i in range(heat.shape[0]):
        for j in range(heat.shape[1]):
            color = "white" if heat[i, j] > 0.55 else PALETTE["dark"]
            ax1.text(j, i, f"{heat[i, j]:.2f}", ha="center", va="center", fontsize=7.5, color=color)
    cbar = fig.colorbar(im, ax=ax1, fraction=0.046, pad=0.02)
    cbar.set_label("Mean selection frequency")

    order = ["Particle", "Flux", "Thermal", "Macro"]
    data = [margin_df[margin_df["event"] == event]["margin"].to_numpy(dtype=float) for event in order]
    positions = np.arange(len(order))
    parts = ax2.violinplot(data, positions=positions, widths=0.74, showmeans=False, showmedians=True, showextrema=False)
    for body in parts["bodies"]:
        body.set_facecolor(PALETTE["teal"])
        body.set_edgecolor("white")
        body.set_alpha(0.72)
    if "cmedians" in parts:
        parts["cmedians"].set_color(PALETTE["dark"])
        parts["cmedians"].set_linewidth(1.2)
    rng = np.random.default_rng(42)
    for idx, values in enumerate(data):
        jitter = rng.normal(0.0, 0.035, size=len(values))
        ax2.scatter(np.full(len(values), idx) + jitter, values, s=8, color=PALETTE["dark"], alpha=0.52, linewidth=0)
    ax2.axhline(0.0, color="#555555", linewidth=0.75)
    ax2.set_xticks(positions)
    ax2.set_xticklabels(order, rotation=20, ha="right")
    ax2.set_ylabel("Normalized loss difference")
    ax2.set_title("(b) Difference vs fixed schedule", loc="left")
    save_pdf_png(fig, OUT_FIG_DIR / "figure_event_type_diagnostics")


def main() -> None:
    OUT_TABLE_DIR.mkdir(parents=True, exist_ok=True)
    OUT_FIG_DIR.mkdir(parents=True, exist_ok=True)
    OUT_AGG_DIR.mkdir(parents=True, exist_ok=True)

    loss_df, action_df, static_rows, metadata_rows = collect()
    static_df = pd.DataFrame(static_rows)
    loss_df.to_csv(OUT_AGG_DIR / "event_type_loss_rows.csv", index=False)
    action_df.to_csv(OUT_AGG_DIR / "event_type_action_rows.csv", index=False)
    static_df.to_csv(OUT_AGG_DIR / "static_selection_rows.csv", index=False)

    write_action_space_table(static_df)
    write_observability_table()
    write_reproducibility_table(metadata_rows)
    write_static_selection_table(static_df)
    write_event_loss_table(loss_df)
    plot_event_diagnostics(loss_df, action_df)

    print(f"Wrote diagnostic assets under {OUT_AGG_DIR}")


if __name__ == "__main__":
    main()
