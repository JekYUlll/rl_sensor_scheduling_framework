#!/usr/bin/env python3
"""Evaluate the frozen TCN forecaster against persistence on validation windows."""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

PAPER_DIR = Path(__file__).resolve().parents[1]
ROOT_DIR = PAPER_DIR.parent
sys.path.insert(0, str(ROOT_DIR / "src"))

from v2.env import WarmupEnvConfig  # noqa: E402
from v2.policies import FullOpenUnconstrainedScorePolicy  # noqa: E402
from v2.power_projector import PowerConstraintsV2  # noqa: E402
from v2.rollout import run_policy_rollout  # noqa: E402
from v2.sensor_spec import load_sensor_specs  # noqa: E402
from v2.oracle import make_oracle_feature  # noqa: E402
from v2.tcn_oracle import TCNFrozenForecastOracle  # noqa: E402

RUN_PREFIX = "v31_metpair_backbone_context_ortholinear_balancedobjective_scenebal2"
RUN_SUFFIX = "h075ctxolscbal2_20260621"
SEEDS = tuple(range(117, 141))

STATE_COLUMNS = (
    "wind_speed_ms",
    "wind_direction_deg",
    "wind_dir_sin",
    "wind_dir_cos",
    "air_temperature_c",
    "relative_humidity",
    "air_pressure_pa",
    "solar_radiation_wm2",
    "snow_surface_temperature_c",
    "snow_particle_mean_diameter_mm",
    "snow_particle_mean_velocity_ms",
    "snow_mass_flux_kg_m2_s",
    "event_subtype_particle_latent",
    "event_subtype_flux_latent",
    "event_subtype_thermal_latent",
)

TARGET_LABELS = {
    "air_temperature_c": "Air temp.",
    "snow_surface_temperature_c": "Surface temp.",
    "wind_speed_ms": "Wind speed",
    "wind_dir_sin": "Wind-dir sin",
    "wind_dir_cos": "Wind-dir cos",
    "solar_radiation_wm2": "Radiation",
    "snow_mass_flux_kg_m2_s": "Snow flux",
    "snow_particle_mean_diameter_mm": "Particle diam.",
    "snow_particle_mean_velocity_ms": "Particle vel.",
}


def run_dir(seed: int) -> Path:
    return ROOT_DIR / "reports" / f"{RUN_PREFIX}_seed{seed}_{RUN_SUFFIX}"


def latex_escape(value: object) -> str:
    text = str(value)
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text


def predict_in_batches(oracle: TCNFrozenForecastOracle, features: np.ndarray, *, batch_size: int) -> np.ndarray:
    preds: list[np.ndarray] = []
    for start in range(0, features.shape[0], int(batch_size)):
        preds.append(oracle.predict(features[start : start + int(batch_size)]))
    return np.vstack(preds)


def rollout_forecast_windows(
    *,
    observations: np.ndarray,
    masks: np.ndarray,
    step_indices: np.ndarray,
    truth_targets: np.ndarray,
    state_mean: np.ndarray,
    lookback: int,
    horizon: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Build full-history validation windows for the frozen-forecaster audit.

    The scheduler environment pads episode starts with zero masks so that PPO
    can receive a reward from the first step. That is not a fair standalone
    validation benchmark for the frozen TCN forecaster: the TCN was trained on
    complete supervised windows and mask channels can have near-zero training
    variance. We therefore exclude the first ``lookback - 1`` steps of each
    rollout segment and compare TCN vs persistence only on complete histories.
    """
    obs = np.asarray(observations, dtype=float)
    mask = np.asarray(masks, dtype=float)
    steps = np.asarray(step_indices, dtype=int).reshape(-1)
    targets = np.asarray(truth_targets, dtype=float)
    del state_mean
    if obs.shape != mask.shape:
        raise ValueError(f"observation/mask mismatch: {obs.shape} != {mask.shape}")
    if obs.shape[0] != steps.shape[0]:
        raise ValueError(f"step index length mismatch: {obs.shape[0]} != {steps.shape[0]}")

    features: list[np.ndarray] = []
    futures: list[np.ndarray] = []
    last_targets: list[np.ndarray] = []
    for local_idx, global_idx in enumerate(steps):
        if int(local_idx) + 1 < int(lookback):
            continue
        start = int(global_idx) + 1
        end = start + int(horizon)
        if start < 0 or end > targets.shape[0]:
            continue
        window_start = int(local_idx) + 1 - int(lookback)
        window_end = int(local_idx) + 1
        obs_window = obs[window_start:window_end]
        mask_window = mask[window_start:window_end]
        if obs_window.shape[0] != int(lookback):
            continue
        features.append(make_oracle_feature(obs_window, mask_window))
        futures.append(targets[start:end])
        last_targets.append(targets[int(global_idx)])
    if not features:
        raise ValueError("No forecast windows built from rollout")
    return np.vstack(features), np.asarray(futures, dtype=float), np.asarray(last_targets, dtype=float)


def seed_rows(seed: int, *, device: str, batch_size: int) -> list[dict[str, float | int | str]]:
    base = run_dir(seed)
    metadata_path = base / "v2_ppo_metadata.json"
    truth_path = base / "truth_v31_split.csv"
    oracle_path = base / "v2_tcn_oracle.pt"
    if not metadata_path.exists() or not truth_path.exists() or not oracle_path.exists():
        missing = [str(p) for p in (metadata_path, truth_path, oracle_path) if not p.exists()]
        raise FileNotFoundError(f"Seed {seed} missing required files: {missing}")

    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    targets = [str(x) for x in metadata["reward_target_columns"]]
    target_scales = np.asarray(metadata.get("target_scales", [1.0] * len(targets)), dtype=float)
    target_weights = np.asarray(metadata.get("target_weights", [1.0] * len(targets)), dtype=float)
    lookback = int(metadata["lookback"])
    horizon = int(metadata["horizon"])
    partition = metadata["partition_protocol"]
    starts = [int(x) for x in partition["static_selection_start_indices"]]
    steps = int(partition["static_selection_steps"])

    truth = pd.read_csv(truth_path, usecols=list(dict.fromkeys([*STATE_COLUMNS, *targets, "event_flag", "event_subtype_id"])))
    state_mean = truth[list(STATE_COLUMNS)].to_numpy(dtype=float).mean(axis=0)
    target_values = truth[targets].to_numpy(dtype=float)
    sensors = load_sensor_specs(str(ROOT_DIR / str(metadata["sensor_cfg"])))
    policy = FullOpenUnconstrainedScorePolicy(n_sensors=len(sensors))
    rollout_features: list[np.ndarray] = []
    rollout_futures: list[np.ndarray] = []
    rollout_last_targets: list[np.ndarray] = []
    for offset, start in enumerate(starts):
        cfg = WarmupEnvConfig(
            state_columns=STATE_COLUMNS,
            reward_target_columns=tuple(targets),
            lookback=lookback,
            episode_len=steps,
            seed=int(seed) + 77_000 + int(offset),
            base_freq_s=int(metadata.get("base_freq_s", 3600)),
        )
        from v2.env import WarmupSchedulingEnv  # local import keeps startup cost low for table rendering

        env = WarmupSchedulingEnv(truth, sensors, PowerConstraintsV2(), cfg)
        result = run_policy_rollout(env, policy, steps=steps, start_idx=int(start))
        features_part, futures_part, last_targets_part = rollout_forecast_windows(
            observations=result.observations,
            masks=result.masks,
            step_indices=result.step_indices,
            truth_targets=target_values,
            state_mean=state_mean,
            lookback=lookback,
            horizon=horizon,
        )
        rollout_features.append(features_part)
        rollout_futures.append(futures_part)
        rollout_last_targets.append(last_targets_part)
    features = np.vstack(rollout_features)
    futures = np.concatenate(rollout_futures, axis=0)

    oracle = TCNFrozenForecastOracle.load(oracle_path, device=device)
    preds = predict_in_batches(oracle, features, batch_size=batch_size).reshape(features.shape[0], horizon, len(targets))

    last_values = np.concatenate(rollout_last_targets, axis=0)
    persistence = np.repeat(last_values[:, None, :], horizon, axis=1)

    tcn_abs = np.abs(preds - futures)
    persistence_abs = np.abs(persistence - futures)
    rows: list[dict[str, float | int | str]] = []
    for idx, target in enumerate(targets):
        scale = float(target_scales[idx]) if idx < target_scales.size and target_scales[idx] > 0 else 1.0
        tcn_mae = float(np.nanmean(tcn_abs[:, :, idx]))
        pers_mae = float(np.nanmean(persistence_abs[:, :, idx]))
        rows.append(
            {
                "seed": seed,
                "target": target,
                "samples": int(features.shape[0]),
                "horizon": int(horizon),
                "target_scale": scale,
                "target_weight": float(target_weights[idx]) if idx < target_weights.size else 1.0,
                "tcn_mae": tcn_mae,
                "persistence_mae": pers_mae,
                "tcn_nmae": tcn_mae / scale,
                "persistence_nmae": pers_mae / scale,
                "relative_gain": (pers_mae - tcn_mae) / pers_mae if pers_mae > 0 else float("nan"),
                "validation_start": int(min(starts)),
                "validation_end": int(max(starts) + steps),
            }
        )
    return rows


def summarise(rows: pd.DataFrame) -> pd.DataFrame:
    grouped = rows.groupby("target", as_index=False).agg(
        samples=("samples", "sum"),
        horizon=("horizon", "first"),
        target_scale=("target_scale", "first"),
        target_weight=("target_weight", "first"),
        tcn_mae=("tcn_mae", "mean"),
        persistence_mae=("persistence_mae", "mean"),
        tcn_nmae=("tcn_nmae", "mean"),
        persistence_nmae=("persistence_nmae", "mean"),
    )
    grouped["relative_gain"] = (grouped["persistence_nmae"] - grouped["tcn_nmae"]) / grouped["persistence_nmae"]
    weights = grouped["target_weight"].to_numpy(dtype=float)
    positive = np.isfinite(weights) & (weights > 0)
    if np.any(positive):
        weights = weights[positive] / float(np.sum(weights[positive]))
        weighted_row = {
            "target": "weighted_mean",
            "samples": int(grouped["samples"].sum()),
            "horizon": int(grouped["horizon"].iloc[0]),
            "target_scale": float("nan"),
            "target_weight": float(np.sum(grouped.loc[positive, "target_weight"])),
            "tcn_mae": float("nan"),
            "persistence_mae": float("nan"),
            "tcn_nmae": float(np.sum(grouped.loc[positive, "tcn_nmae"].to_numpy(dtype=float) * weights)),
            "persistence_nmae": float(
                np.sum(grouped.loc[positive, "persistence_nmae"].to_numpy(dtype=float) * weights)
            ),
        }
        weighted_row["relative_gain"] = (
            (weighted_row["persistence_nmae"] - weighted_row["tcn_nmae"]) / weighted_row["persistence_nmae"]
            if weighted_row["persistence_nmae"] > 0
            else float("nan")
        )
        grouped = pd.concat([grouped, pd.DataFrame([weighted_row])], ignore_index=True)
    order = {target: idx for idx, target in enumerate([*TARGET_LABELS.keys(), "weighted_mean"])}
    grouped["_order"] = grouped["target"].map(order).fillna(999).astype(int)
    return grouped.sort_values("_order").drop(columns=["_order"]).reset_index(drop=True)


def fmt(value: float, digits: int = 3) -> str:
    if not math.isfinite(float(value)):
        return "--"
    return f"{float(value):.{digits}f}"


def write_latex(summary: pd.DataFrame, path: Path) -> None:
    rows = []
    for _, item in summary.iterrows():
        target = str(item["target"])
        label = "Weighted mean" if target == "weighted_mean" else TARGET_LABELS.get(target, target)
        rows.append(
            "    "
            + " & ".join(
                [
                    latex_escape(label),
                    fmt(float(item["tcn_nmae"])),
                    fmt(float(item["persistence_nmae"])),
                    fmt(100.0 * float(item["relative_gain"]), 1),
                    fmt(float(item["tcn_mae"]), 4),
                ]
            )
            + r" \\"
        )
    content = "\n".join(
        [
            r"\begin{table}[htbp]",
            r"  \centering",
            r"  \caption{Diagnostic fixed TCN forecaster validation benchmark against persistence.}",
            r"  \label{tab:tcn_forecaster_validation}",
            r"  \small",
            r"  \setlength{\tabcolsep}{4pt}",
            r"  \begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}lcccc@{}}",
            r"    \toprule",
            r"    Target & TCN nMAE & Persistence nMAE & Gain (\%) & TCN MAE \\",
            r"    \midrule",
            *rows,
            r"    \bottomrule",
            r"  \end{tabular*}",
            r"  \vspace{0.4ex}",
            "",
            r"  \noindent\footnotesize",
            r"  Values are averaged over 24 seeds on the validation/static-selection",
            r"  partition using full-open sensor rollouts. nMAE divides MAE by the",
            r"  target scale used by the fixed forecaster. The table is a diagnostic",
            r"  audit and is not used to support the scheduler superiority claim.",
            r"\end{table}",
            "",
        ]
    )
    path.write_text(content, encoding="utf-8")


def write_report(summary: pd.DataFrame, rows: pd.DataFrame, path: Path) -> None:
    weighted = summary[summary["target"] == "weighted_mean"].iloc[0]
    content = "\n".join(
        [
            "# Fixed TCN Forecaster Validation Benchmark",
            "",
            "Source: 24 main benchmark seeds 117--140.",
            "",
            "Protocol: each seed loads its frozen `v2_tcn_oracle.pt`; windows are built",
            "from the validation/static-selection partition using full-open sensor",
            "rollouts. The first `lookback - 1` warm-up steps of each rollout",
            "segment are excluded because the standalone TCN was trained on",
            "complete supervised windows rather than padded episode starts.",
            "Persistence repeats the last observed target value over the same",
            "forecast horizon.",
            "",
            f"Rows: {len(rows)} seed-target rows.",
            f"Weighted TCN nMAE: {float(weighted['tcn_nmae']):.6f}.",
            f"Weighted persistence nMAE: {float(weighted['persistence_nmae']):.6f}.",
            f"Weighted relative gain: {100.0 * float(weighted['relative_gain']):.2f}%.",
            "",
            "Artifacts:",
            "- `reports/aggregate/tcn_forecaster_validation_20260624_corrected/seed_target_rows.csv`",
            "- `reports/aggregate/tcn_forecaster_validation_20260624_corrected/summary.csv`",
            "- `paper/tables/tcn_forecaster_validation.tex`",
            "",
        ]
    )
    path.write_text(content, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--batch-size", type=int, default=2048)
    args = parser.parse_args()

    all_rows: list[dict[str, float | int | str]] = []
    for seed in SEEDS:
        all_rows.extend(seed_rows(seed, device=str(args.device), batch_size=int(args.batch_size)))
    rows = pd.DataFrame(all_rows)
    summary = summarise(rows)

    out_dir = ROOT_DIR / "reports" / "aggregate" / "tcn_forecaster_validation_20260624_corrected"
    out_dir.mkdir(parents=True, exist_ok=True)
    rows.to_csv(out_dir / "seed_target_rows.csv", index=False)
    summary.to_csv(out_dir / "summary.csv", index=False)
    write_latex(summary, PAPER_DIR / "tables" / "tcn_forecaster_validation.tex")
    write_report(summary, rows, out_dir / "report.md")
    print(f"Wrote TCN forecaster validation benchmark to {out_dir}")


if __name__ == "__main__":
    main()
