#!/usr/bin/env python
"""Generate the validation-frozen mechanism-ablation table."""
from __future__ import annotations

import argparse
import math
from pathlib import Path

import pandas as pd


def number(value: object) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return float("nan")
    return result if math.isfinite(result) else float("nan")


def count(row: pd.Series, column: str) -> str:
    return f"{int(row[column])}/{int(row['complete_seeds'])}"


def interval(row: pd.Series, low: str, high: str) -> str:
    return f"$[{number(row[low]):.4f}, {number(row[high]):.4f}]$"


def delta(row: pd.Series) -> tuple[str, str]:
    value = number(row["paired_delta_macro_margin_mean_vs_full"])
    if not math.isfinite(value):
        return "--", "--"
    return f"{value:.4f}", interval(row, "paired_delta_macro_margin_ci_low_vs_full", "paired_delta_macro_margin_ci_high_vs_full")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--summary-csv", required=True)
    parser.add_argument("--out-tex", default="paper/tables/mechanism_ablation_summary.tex")
    args = parser.parse_args()

    rows = pd.read_csv(args.summary_csv)
    lines = [
        r"\begin{table}[htbp]",
        r"  \centering",
        r"  \caption{Ablation study with validation-frozen macro scoring over 24 seeds.}",
        r"  \label{tab:mechanism_ablation_summary}",
        r"  \scriptsize",
        r"  \setlength{\tabcolsep}{3.0pt}",
        r"  \renewcommand{\arraystretch}{1.10}",
        r"  \begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}p{0.27\linewidth}ccccc@{}}",
        r"    \toprule",
        r"    Policy variant & Macro wins & Step wins & Zero abort & \shortstack{Mean macro\\margin} & \shortstack{$\Delta$ vs full} \\",
        r"    \midrule",
    ]
    for _, row in rows.iterrows():
        delta_value, delta_interval = delta(row)
        lines.extend(
            [
                "    {label} & {macro} & {step} & {abort} & {mean:.4f} & {delta} \\\\".format(
                    label=str(row["variant_label"]),
                    macro=count(row, "macro_win_count"),
                    step=count(row, "step_win_count"),
                    abort=count(row, "zero_abort_count"),
                    mean=number(row["macro_margin_mean"]),
                    delta=delta_value,
                ),
                "    \\multicolumn{{4}}{{r}}{{\\emph{{95\\% CI}}}} & {mean_ci} & {delta_ci} \\\\".format(
                    mean_ci=interval(row, "macro_margin_mean_ci_low", "macro_margin_mean_ci_high"),
                    delta_ci=delta_interval,
                ),
                r"    \addlinespace[0.25ex]",
            ]
        )
    lines.extend(
        [
            r"    \bottomrule",
            r"  \end{tabular*}",
            r"  \renewcommand{\arraystretch}{1.0}",
            r"  \vspace{0.4ex}",
            "",
            r"  \noindent\footnotesize",
            r"  Margins are validation-selected fixed-schedule loss minus PD-PPO loss,",
            r"  using event-type denominators fixed from validation candidates. The second",
            r"  row for each variant gives percentile bootstrap 95\% confidence intervals",
            r"  over seeds; $\Delta$ is the paired mean change from the full policy.",
            r"  Zero abort reports final-test rollouts with no warm-up aborts. The intervals",
            r"  do not identify a large isolated macro contribution from one auxiliary term.",
            r"\end{table}",
            "",
        ]
    )
    Path(args.out_tex).write_text("\n".join(lines), encoding="utf-8")
    print(f"wrote {args.out_tex}")


if __name__ == "__main__":
    main()
